#!/bin/sh
# oXygen HTTP License Server startup script

startLicenseServer() {
# Resolve the location of the installation.
# This includes resolving any symlinks.
PRG=$0
while [ -h "$PRG" ]; do
    ls=`ls -ld "$PRG"`
    link=`expr "$ls" : '^.*-> \(.*\)$' 2>/dev/null`
    if expr "$link" : '^/' 2> /dev/null >/dev/null; then
        PRG="$link"
    else
        PRG="`dirname "$PRG"`/$link"
    fi
done

OXYGEN_HOME=`dirname "$PRG"`

# Absolutize dir
cd "${OXYGEN_HOME}"

OXYGEN_JAVA=java
if [ -f "${JAVA_HOME}/bin/java" ]
then
  OXYGEN_JAVA="${JAVA_HOME}/bin/java"
fi
if [ -f "${OXYGEN_HOME}/jre/bin/java" ]
then
  OXYGEN_JAVA="${OXYGEN_HOME}/jre/bin/java"
fi

# This is the command line for the license server.
CMDLINE="-jar lib/jetty-license-server.jar"

# This is the port to connect to.
# If this param is missing, the default value is 	8080
PORT=$1

if [ "$PORT" != "" ]; then
  CMDLINE="-Dcom.oxygenxml.licenseserver.port=${PORT} ${CMDLINE}"
fi

# Start the server.
exec "${OXYGEN_JAVA}" ${CMDLINE}
}

if [ "$1" = "" ]; then
echo "Usage: "
echo "  sh licenseServer.sh [port] "
echo "    port - the port of the license server "
echo "No argument is given running on default port \"8080\".\n"
fi

if [ "$1" != "" ]; then
  echo "Go to http://localhost:${1}/oXygenLicenseServlet/index.jsp to manage the license server"
else 
  echo "Go to http://localhost:8080/oXygenLicenseServlet/index.jsp to manage the license server"
fi

startLicenseServer $1