== User Roles ==
 The oXygen HTTP License Server has two levels of security
    * admin - These accounts have the highest security clearance, having access to all administrative tasks (such as configuring the license server's license).
    * manager - These accounts only have access to the initial page and report pages.
    * user - These accounts are used by the Oxygen product suite to request licenses from the license server.

These credentials can be configured by editing the passwords.properties file that is located in the License Server installation directory.
To configure a user, add a user descriptor, one per line. The user descriptor pattern is "username: password,role", where 'role' can be "admin", "manager", or "user".

== Managing the Server == 
The oXygen HTTP License Server Manager can be accessed at 'http://localhost:${installer:port}/', "admin" or "manager" credentials will be required for this task.
From here, you can perform various management tasks, such as viewing and changing the license the server dispatches and consulting statistics about the license usage.
